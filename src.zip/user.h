#pragma once


#include <iostream>


template <typename T>
class User
{
    friend void Urlgeneration(User<T>* user);
private:
    T* sequence;
    static int digits;
public:
    
    int variety()
    {
       std::vector<T> unique;
       for(int i = 0; i < digits; i++)
       {
            bool found = false;
            for(T& u : unique)
            {
                if(u == sequence[i])
                    found = true;
            }
            if(!found)
                unique.push_back(sequence[i]);
       }
       return unique.size();
    }

    int difference(User<T>* that)
    {
        int difference = 0;
        for(int i = 0; i < digits; i++)
        {
            int d = this->sequence[i] != that->sequence[i];
            std::cout << d << " ";
            difference += d;
        }
        return difference;
    }

    static void setDigits(int d)
    {
        digits = d;
    }

    void display()
    {
        for(int i = 0; i < digits; i++)
        {
            std::cout << sequence[i] << " ";
        }
        std::cout << std::endl;
    }

    User()
    {
        if(digits > 0)
            sequence = new T[digits];
        else
            sequence = nullptr;
    }

    ~User()
    {
        if(sequence != nullptr)
            delete[] sequence;
    }
};