#include "user.h"

int User<int>::digits;