#pragma once
#include <iostream>

template <typename T>
class Pool
{
private:
    T* data;
    int size;
public:
    Pool(int size)
    {
        this->size = size;
        if(size > 0)
            data = new T[size];
        else
            data = nullptr;
    }

    ~Pool()
    {
        if(data != nullptr)
            delete[] data; 
    }

    void display()
    {
        for(int i = 0; i < this->size; i++)
        {
            data[i].display();
        }
    }

    void minimumVareity()
    {
        int minimum = INT32_MAX;
        for(int i = 0; i < this->size; i++)
        {
            minimum = std::min(data[i].variety(), minimum);
        }
        std::cout << "Minimum Variety was: " << minimum << std::endl;
    }

    void minimumDifference()
    {
        int minimum = INT32_MAX;
        for(int ifirst = 0; ifirst < size; ifirst++)
        {
            for(int isecond = ifirst + 1; isecond < size; isecond++)
            {
                T* first = &data[ifirst];
                T* second = &data[isecond];

                std::cout << "     ";
                first->display();
                std::cout << "(vs) ";
                second->display();
                std::cout << "  => ";
                int difference = first->difference(second);
                std::cout << " => " << difference << std::endl << std::endl;
                minimum = std::min(difference, minimum);
            }
        }
        std::cout << "Minimum difference was: " << minimum << std::endl;
    }

    template<typename Iterator>
    void iterate(Iterator iterator)
    {
        for(int i = 0; i < this->size; i++)
        {
            iterator(&data[i]);
        }
    }
};