





#include <cstdio>
#include <cstdlib>
#include <random>
#include <chrono>

#include "user.h"
#include "pool.h"

void inputFormattingError()
{
    printf("You need to format your input as: Monitor <digit> <users>, where n and m are numbers greater then 0\n");
    exit(1);
}

void Urlgeneration(User<int>* user)
{
    std::default_random_engine generator(std::chrono::system_clock::now().time_since_epoch().count());

    std::uniform_int_distribution<int> distro(0, 9);

    for(int i = 0; i < User<int>::digits; i++)
    {
        user->sequence[i] = distro(generator);
    }
}

int main(int argc, char** argv)
{
    if(argc != 3)
    {
        inputFormattingError();
    }

    int digits = atoi(argv[1]);
    int users = atoi(argv[2]);
    
    if(digits == 0 || users == 0)
    {
        inputFormattingError();
    }

    User<int>::setDigits(digits);

    Pool<User<int>> pool(users);

    pool.iterate([](User<int>* user)
    {
        Urlgeneration(user);
    });

    pool.display();
    pool.minimumVareity();
    pool.minimumDifference();

    return 0;
}